import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListPostComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';

@NgModule({
  declarations: [ListPostComponent, DetailComponent],
  imports: [
    CommonModule
  ]
})
export class PostModule { }
