import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListPostComponent } from './post/list/list.component';
import { PostService } from './core/service/post.service';
import { HomeComponent } from './home/home.component';
import { DetailComponent } from './post/detail/detail.component';

@NgModule({
  declarations: [
    AppComponent,
    ListPostComponent,
    DetailComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [PostService],
  bootstrap: [AppComponent]
})
export class AppModule { }
